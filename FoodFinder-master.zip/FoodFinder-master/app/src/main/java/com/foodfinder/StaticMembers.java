package com.foodfinder;

public class StaticMembers {

    public static final String RESTAURANT_EXTRA = "RESTAURANT_EXTRA";
    public static final String RESTAURANT_DETAILS = "RESTAURANT_DETAILS";
}
